#!/bin/bash
echo "Starting Instagram Scraper..."
echo

# Check if running executable or source
if [ -f "./instagram-scraper" ]; then
    ./instagram-scraper
else
    python3 src/cli.py
fi

read -p "Press Enter to exit..."
