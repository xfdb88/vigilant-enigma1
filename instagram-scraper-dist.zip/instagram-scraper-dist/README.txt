# Instagram Public Profile Scraper

## Quick Start

### Method 1: Run the executable (Recommended)
1. Run `instagram-scraper.exe` (Windows) or `./instagram-scraper` (Linux/Mac)
2. Follow the on-screen instructions

### Method 2: Run from source
1. Install Python 3.8 or higher
2. Install dependencies: `pip install -r requirements.txt`
3. Install Playwright browsers: `playwright install chromium`
4. Copy `.env.example` to `.env` and configure (optional)
5. Run: `python src/cli.py`

## Usage

1. Prepare your input file:
   - Edit `data/input.csv` with Instagram usernames (one per line)
   - Example:
     ```
     username
     instagram
     natgeo
     ```

2. Run the scraper:
   - Choose option 1 from the menu to scrape from CSV
   - Or choose option 2 to scrape a single profile

3. Results will be saved to `data/output.csv`

## Configuration

Edit the `.env` file to customize:
- Request timeout
- Retry settings
- Rate limiting
- Proxy settings (optional)

## Important Notes

⚠️ **Legal Disclaimer**: This tool is for educational purposes only.
- Only scrape publicly available information
- Respect Instagram's Terms of Service
- Comply with data protection laws (GDPR, CCPA, etc.)

## License

MIT License - See LICENSE file for details
