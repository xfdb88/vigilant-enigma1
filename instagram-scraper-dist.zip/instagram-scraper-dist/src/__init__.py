"""
Instagram Public Profile Scraper Package
"""

__version__ = '1.0.0'
__author__ = 'vigilant-enigma1'
__license__ = 'MIT'
